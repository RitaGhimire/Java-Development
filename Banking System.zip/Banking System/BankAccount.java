public class BankAccount { //declaring a class named BankAccount
    public static int TotalAccountCount = 1 ; // declaring an integer to keep track of total number of accounts.
    private String accountNumber; // initially declaring the accountNumber, accountHolder and balance so that it can be used inside every methods without having to intialize it

    private String accountHolder;
    private double balance;

    // this is a compartment for the class BankAccount which has accountholder and balance also it gives the accountNumber.
    public BankAccount(String accountHolder, double balance){
        this.accountHolder = accountHolder;
       this.accountNumber = "PNC" + TotalAccountCount++;
        this.balance = balance;
    }
    // this method is used to add deposit amount to the initial amount
    public void deposit(double amount) {
        balance += amount;
        if (balance >= 0) {
            System.out.println("Your balance has been deposited successfully.");
            System.out.println("Your new balance amount is " + balance);
        } else {
            System.out.println("The amount you deposited is in negative amount.");
        }
    }
    // this method is used to withdraw amount from the balance present in the account
        public void withdraw(double amount) {
            if (balance >= amount) {
                balance -= amount;
                System.out.printf("You withdrew %f from your account", amount);
            } else {
                System.out.print("The balance amount provided is insufficient or invalid");
            }
        }
    // this method is created to display accountholdername,accountnumber and balance
        public void displayAccountDetails(){
            System.out.println("The Account Number is: " + accountNumber);
            System.out.println("The Account Holder is: " +accountHolder);
            System.out.println("The total balance is: " + balance);

        }
    // this method is used to get that specific accountnumber which is used in bank class and main class
        public String getAccountNumber(){
        return accountNumber;
        }
    }

