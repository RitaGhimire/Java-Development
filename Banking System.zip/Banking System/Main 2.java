
import java.sql.SQLOutput;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      boolean exit = false;
        Bank bank = new Bank(500); // this is the maximum number of bank accounts this system can have
        while (!exit) {
            System.out.println("What would you like to do today?"); // asking what user is looking for
            System.out.println();
            System.out.println("1.Create an Account");
            System.out.println("2.Deposit the money");
            System.out.println("3.Withdraw the money");
            System.out.println("4.Display the Account Details");
            System.out.println("5.Display All Accounts ");
            System.out.println("6.Exit");
            System.out.println();
            System.out.println("Enter the number as instructed above: ");
            int purpose = input.nextInt();
            String CustomerAccNumber;
            switch (purpose) {
                //this case asks for user to create a new  account
                case 1:
                    System.out.print("Enter the account holder name: ");
                    String accountHolder = input.next();
                    System.out.print("Enter your inital deposit amount: ");
                    double DepositAmount = input.nextDouble();
                    while (DepositAmount < 0 || Double.isNaN(DepositAmount)) {
                        System.out.println("Enter a valid number");
                        System.out.print("Enter your inital deposit amount: ");
                        DepositAmount = input.nextDouble();
                    }
                    System.out.println();
                    BankAccount newAccount = new BankAccount(accountHolder, DepositAmount);
                    bank.addingAccount(newAccount);
                    System.out.println();
                    System.out.printf("Congratulations! %s Your account has been created.\n", accountHolder);
                    System.out.println("Your new account number is: " + newAccount.getAccountNumber());
                    System.out.println();

                    break;
                    // this case asks for user to deposit an amount
                case 2:
                    System.out.println("Enter your account number: ");
                          CustomerAccNumber = input.next();
                        System.out.println("Enter your deposit amount: ");
                        double depositedInput = input.nextDouble();
                    while (depositedInput < 0 || Double.isNaN(depositedInput)) {
                        System.out.println("Enter a valid number");
                        System.out.print("Enter your  deposit amount: ");
                        depositedInput = input.nextDouble();
                    }
                        BankAccount account = bank.findingAccount(CustomerAccNumber);
                   if(account != null) {
                       account.deposit(depositedInput);
                   }else {
                       System.out.println("Sorry,the account doesn't exist");
                       System.out.println();
                   }

                    break;
                    // this case asks for user to an amount
                case 3:
                    System.out.println("Enter your account number: ");
                    CustomerAccNumber = input.next();
                    System.out.println("Enter the amount of withdrawal:  ");
                    double withdrawAmount = input.nextDouble();
                    while (withdrawAmount < 0 || Double.isNaN(withdrawAmount)) {
                        System.out.println("Enter a valid number");
                        System.out.print("Enter your  deposit amount: ");
                        withdrawAmount = input.nextDouble();
                    }
                    account = bank.findingAccount(CustomerAccNumber);
                    if(account!= null) {
                        account.withdraw(withdrawAmount);
                    }else{
                        System.out.println("Sorry,the account doesn't exist");
                        System.out.println();
                    }
                    break;
                // this case gives detail about specific bank account
                case 4:
                    System.out.println("Enter your account number: ");
                    CustomerAccNumber = input.next();
                    account = bank.findingAccount(CustomerAccNumber);
                    if (account != null) {
                       account.displayAccountDetails();
                    } else {
                        System.out.println("Sorry,the account doesn't exist");
                        System.out.println();
                    }
                    break;
                // this case asks for displaying all the account details
                case 5:
                    bank.DisplayAccounts();
                    break;
                // this case asks if they want to exittttttt
                case 6:
                    System.out.println("..........The End.......");
                    exit = true;
                    break;
                // if any case doesn't work!!!!!!
                default:
                    System.out.println("Please enter correct option");
            }
            }
        input.close();
        }
    }
















