
public class Bank {   //declaring a class named Bank
    private final BankAccount[] account; // this is setting a method for account using BankAccount[] which is needed to
    private int totalAccounts; // this keeps track of total accounts

    // this is a compartment for the class Bank
    public Bank(int maximumBankAccounts){
        account = new BankAccount[maximumBankAccounts];
         totalAccounts = 0;
    }
    // this method is used for adding the account to keep the track of accounts
    public void addingAccount(BankAccount acc){
        if(totalAccounts < account.length) {
            account[totalAccounts] = acc;
            totalAccounts++;
            System.out.println("Account has successfully been added");
        }else{
            System.out.println("Further accounts cannot be added due to bank being out of space");
        }
    }
    // this method helps in finding the account for find account details
    public BankAccount findingAccount(String AccountNo){
        for(int i= 0; i < totalAccounts ; i++) {
            if(account[i].getAccountNumber().equals(AccountNo)){
                return account[i];
        }
        }
        return null;
    }
    // this method is used to display all the accounts
    public void DisplayAccounts() {
        if(totalAccounts > 0) {
            for (int i = 0; i < totalAccounts; i++) {
                account[i].displayAccountDetails();
                System.out.println("HERE IS THE DETAILS");
                System.out.println("/////////////////////////////////");
                System.out.println();
            }
        }else{
                System.out.println("Account doesn't exist ");
            System.out.println();
        }

    }
}